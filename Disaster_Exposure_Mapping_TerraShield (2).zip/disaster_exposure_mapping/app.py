from flask import Flask, render_template, jsonify, request
import json, math, os

app = Flask(__name__)

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def load_json(name):
    with open(os.path.join(DATA_DIR, name), "r", encoding="utf-8") as f:
        return json.load(f)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/summary")
def summary():
    return jsonify(load_json("summary.json"))

@app.route("/api/layers")
def layers():
    return jsonify(load_json("layers.json"))

@app.route("/api/exposure")
def exposure():
    return jsonify(load_json("exposure.json"))

@app.route("/api/analyze", methods=["POST"])
def analyze():
    body = request.get_json(silent=True) or {}
    hazard = body.get("hazard", "Flood")
    threshold = float(body.get("threshold", 60))

    data = load_json("exposure.json")
    filtered = [x for x in data if x["risk_score"] >= threshold]

    return jsonify({
        "hazard": hazard,
        "threshold": threshold,
        "affected_buildings": sum(x["buildings"] for x in filtered),
        "affected_population": sum(x["population"] for x in filtered),
        "affected_roads_km": round(sum(x["roads_km"] for x in filtered), 2),
        "high_risk_zones": len(filtered),
        "zones": filtered
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
