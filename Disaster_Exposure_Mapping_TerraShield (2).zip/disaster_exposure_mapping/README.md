# Disaster Exposure Mapping

A ready-to-run Flask web application for the hackathon problem statement:

Hazard Layer + Roads + Buildings + Population + Land Use
→ Exposure Analysis → Interactive Dashboard → Decision Support

## Features

- Interactive dark GIS-style dashboard
- Hazard selector: Flood, Cyclone, Landslide, Fire
- Exposure threshold control
- Interactive map with sample exposure zones
- Exposure statistics for buildings, population and roads
- Risk-zone table
- Layer visibility controls
- Timeline / satellite-data concept panel
- Decision recommendations
- Flask backend API
- Clean separation of HTML, CSS, JavaScript and data

## Run in VS Code

### 1. Open this folder in VS Code

Open the `disaster_exposure_mapping` folder.

### 2. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

### 3. Install packages

```bash
pip install -r requirements.txt
```

### 4. Start the server

```bash
python app.py
```

### 5. Open the website

Go to:

http://127.0.0.1:5000

## Important

The included dataset is demonstration data so the application works immediately without an external API.

For the final hackathon version, replace `data/*.json` with real outputs generated using Google Earth Engine / Sentinel-1 / Sentinel-2 / SRTM / Dynamic World / OpenStreetMap.

A simple production architecture is:

Satellite data
→ preprocessing
→ hazard detection
→ GIS exposure intersection
→ risk score
→ Flask API
→ interactive dashboard

## GitHub

```bash
git init
git add .
git commit -m "Initial disaster exposure mapping application"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Deployment

This Flask project can be deployed on Render, Railway, PythonAnywhere or another service supporting Python web applications.
