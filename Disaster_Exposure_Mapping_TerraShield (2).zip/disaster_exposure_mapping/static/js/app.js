let map;
let markers = [];
let exposureData = [];

document.addEventListener("DOMContentLoaded", async () => {
  map = L.map("map", {zoomControl:false}).setView([13.055,80.245], 12);
  L.control.zoom({position:"bottomright"}).addTo(map);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution:"© OpenStreetMap contributors",
    opacity:0.45
  }).addTo(map);

  document.getElementById("threshold").addEventListener("input", e => {
    document.getElementById("thresholdValue").textContent = e.target.value;
  });
  document.getElementById("analyzeBtn").addEventListener("click", runAnalysis);
  document.getElementById("refreshBtn").addEventListener("click", loadAll);
  document.getElementById("exportBtn").addEventListener("click", exportCSV);

  await loadAll();
});

async function loadAll(){
  const [summary, layers, exposure] = await Promise.all([
    fetch("/api/summary").then(r=>r.json()),
    fetch("/api/layers").then(r=>r.json()),
    fetch("/api/exposure").then(r=>r.json())
  ]);
  exposureData = exposure;
  updateStats(summary);
  renderLayers(layers.layers);
  renderZones(exposureData);
  renderMap(exposureData);
  renderRecommendations(exposureData);
}

function updateStats(s){
  document.getElementById("confidence").textContent = s.data_confidence + "%";
  document.getElementById("buildings").textContent = s.affected_buildings.toLocaleString();
  document.getElementById("population").textContent = s.affected_population.toLocaleString();
  document.getElementById("roads").textContent = s.affected_roads_km + " km";
  document.getElementById("zones").textContent = s.high_risk_zones;
}

function renderLayers(layers){
  const el = document.getElementById("layerList");
  el.innerHTML = layers.map(l => `
    <div class="layer-row">
      <span>${l.name}</span>
      <span class="switch ${l.enabled ? "on":""}" data-id="${l.id}"></span>
    </div>`).join("");
  document.querySelectorAll(".switch").forEach(s => s.onclick = () => s.classList.toggle("on"));
}

function renderMap(data){
  markers.forEach(m => map.removeLayer(m));
  markers = [];
  data.forEach(z => {
    const color = z.risk_score >= 75 ? "#ff765f" : z.risk_score >= 60 ? "#e8c961" : "#66c99d";
    const marker = L.circleMarker([z.lat,z.lng], {
      radius: 10 + z.risk_score/18,
      color, fillColor:color, fillOpacity:.28, weight:2
    }).addTo(map);
    marker.bindPopup(`
      <b>${z.name}</b><br>
      Risk score: <b>${z.risk_score}</b><br>
      Buildings: ${z.buildings.toLocaleString()}<br>
      Population: ${z.population.toLocaleString()}<br>
      Roads: ${z.roads_km} km
    `);
    markers.push(marker);
  });
}

function renderZones(data){
  document.getElementById("zoneTable").innerHTML = data.map(z => {
    const cls = z.risk_score >= 75 ? "high" : z.risk_score >= 60 ? "medium" : "low";
    return `<tr>
      <td><b>${z.id}</b> · ${z.name}</td>
      <td><span class="risk-pill ${cls}">${z.risk_score}</span></td>
      <td>${z.buildings.toLocaleString()}</td>
      <td>${z.population.toLocaleString()}</td>
      <td>${z.roads_km} km</td>
      <td>${z.landuse}</td>
    </tr>`;
  }).join("");
}

function renderRecommendations(data){
  const high = [...data].sort((a,b)=>b.risk_score-a.risk_score).slice(0,3);
  document.getElementById("recommendations").innerHTML = high.map((z,i) => `
    <div class="recommend"><b>${i+1}. ${z.name}</b> — Prioritize field verification and emergency-access planning for ${z.population.toLocaleString()} exposed people.</div>
  `).join("");
}

async function runAnalysis(){
  const threshold = document.getElementById("threshold").value;
  const hazard = document.getElementById("hazardSelect").value;
  const btn = document.getElementById("analyzeBtn");
  btn.disabled = true; btn.textContent = "ANALYZING...";
  const result = await fetch("/api/analyze", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({hazard,threshold})
  }).then(r=>r.json());

  document.getElementById("buildings").textContent = result.affected_buildings.toLocaleString();
  document.getElementById("population").textContent = result.affected_population.toLocaleString();
  document.getElementById("roads").textContent = result.affected_roads_km + " km";
  document.getElementById("zones").textContent = result.high_risk_zones;
  renderZones(result.zones);
  renderMap(result.zones);
  renderRecommendations(result.zones);
  btn.disabled = false; btn.innerHTML = 'RUN EXPOSURE ANALYSIS <span>→</span>';
}

function exportCSV(){
  const header = ["Zone","Risk Score","Buildings","Population","Roads km","Land Use"];
  const rows = exposureData.map(z => [z.id,z.risk_score,z.buildings,z.population,z.roads_km,z.landuse]);
  const csv = [header,...rows].map(r=>r.join(",")).join("\n");
  const blob = new Blob([csv],{type:"text/csv"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "disaster_exposure_zones.csv";
  a.click();
}
